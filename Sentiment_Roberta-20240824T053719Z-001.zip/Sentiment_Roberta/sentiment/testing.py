import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import json

def analyze_sentiment(text, model, tokenizer):
    inputs = tokenizer(text, return_tensors="pt", max_length=512, truncation=True, padding='max_length')
    with torch.no_grad():
        outputs = model(**inputs)
        logits = outputs.logits
    probabilities = torch.sigmoid(logits).tolist()[0]
    predicted_labels = [sentiment_labels[i] for i, prob in enumerate(probabilities) if prob > 0.5]
    if predicted_labels == ["bad","good"]:
        predicted_labels = ["neutral"]
    if len(predicted_labels) > 2:
        indx = probabilities.index(max(probabilities))
        predicted_labels = [sentiment_labels[indx]]
    return predicted_labels, probabilities

# Constants
sentiment_labels = ["bad", "neutral", "good"]

label_map = {
    1: ["bad"],
    2: ["bad"],
    3: ["bad"],
    4: ["bad", "neutral"],
    5: ["bad", "neutral"],
    6: ["neutral"],
    7: ["neutral", "good"],
    8: ["neutral", "good"],
    9: ["good"],
    10: ["good"]
}

# Load testing data
with open('sentiment/testing_data.json', 'r') as json_file:
    data_list = json.load(json_file)

# Initialize the results structure
all_results = {}
for movie_dict in data_list:
    movie_id = movie_dict["movie_id"]
    review = movie_dict["review"]
    rating = movie_dict["rating"]
    actual_sentiment = label_map[rating]
    if movie_id not in all_results:
        all_results[movie_id] = {}
    all_results[movie_id][review] = {}
    all_results[movie_id][review]["actual_sentiment"] = actual_sentiment

# Analyze sentiments using different models
for idx in range(1, 11):
    print (f"Going through model {idx}")
    model_name = f"sentiment_roberta_{idx}"
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForSequenceClassification.from_pretrained(model_name)

        for movie_dict in data_list:
            review = movie_dict["review"]
            movie_id = movie_dict["movie_id"]

            sentiments, _ = analyze_sentiment(review, model, tokenizer)

            # Determine the dominant sentiment for simplicity; adjust as needed
            dominant_sentiment = sentiments[0] if sentiments else "unknown"
            all_results[movie_id][review][idx] = dominant_sentiment

    except Exception as e:
        print(f"Error with model {model_name}: {e}")

# Save all_results to a JSON file
with open('sentiment_analysis_results.json', 'w') as json_file:
    json.dump(all_results, json_file, indent=4)

print("****************************COMPLETED**************************")