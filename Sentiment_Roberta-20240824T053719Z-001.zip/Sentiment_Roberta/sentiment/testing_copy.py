import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import json

print("Starting the script...")

def analyze_sentiment(text, model, tokenizer):
    print("Analyzing sentiment for text:", text[:50])
    inputs = tokenizer(text, return_tensors="pt", max_length=512, truncation=True, padding='max_length')
    with torch.no_grad():
        outputs = model(**inputs)
        logits = outputs.logits
    probabilities = torch.sigmoid(logits).tolist()[0]
    predicted_labels = [sentiment_labels[i] for i, prob in enumerate(probabilities) if prob > 0.5]
    return predicted_labels, probabilities

# Constants
sentiment_labels = ["bad", "neutral", "good"]

label_map = {
    1: ["bad"],
    2: ["bad"],
    3: ["bad"],
    4: ["bad", "neutral"],
    5: ["bad", "neutral"],
    6: ["neutral"],
    7: ["neutral", "good"],
    8: ["neutral", "good"],
    9: ["good"],
    10: ["good"]
}

print("Loading testing data...")
with open('sentiment/testing_data.json', 'r') as json_file:
    data_list = json.load(json_file)
print(f"Loaded {len(data_list)} data points.")

all_results = {}
for movie_dict in data_list:
    movie_id = movie_dict["movie_id"]
    review = movie_dict["review"]
    rating = movie_dict["rating"]
    actual_sentiment = label_map[rating]
    if movie_id not in all_results:
        all_results[movie_id] = {}
    all_results[movie_id][review] = {}
    all_results[movie_id][review]["actual_sentiment"] = actual_sentiment

for idx in range(1, 11):
    print(f"\nLoading model {idx}...")
    model_name = f"sentiment_roberta_{idx}"
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForSequenceClassification.from_pretrained(model_name)

        print(f"Analyzing sentiments using model {idx}...")
        for movie_dict in data_list:
            review = movie_dict["review"]
            movie_id = movie_dict["movie_id"]
            sentiments, _ = analyze_sentiment(review, model, tokenizer)

            dominant_sentiment = sentiments[0] if sentiments else "unknown"
            all_results[movie_id][review][idx] = dominant_sentiment
        print(f"Completed sentiment analysis for model {idx}.")

    except Exception as e:
        print(f"Error with model {model_name}: {e}")

# Save all_results to a JSON file
with open('sentiment_analysis_results.json', 'w') as json_file:
    json.dump(all_results, json_file, indent=4)

print("\nProcessing complete!")
